## You can see all projects in action here

[Projects](https://oli-coder.github.io/vanilla/)
